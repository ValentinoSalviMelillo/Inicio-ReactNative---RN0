Primer trabajo en react native
